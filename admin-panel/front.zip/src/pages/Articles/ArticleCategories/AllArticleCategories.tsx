// src/pages/Articles/ArticleCategories/AllArticleCategories.tsx
import { useState } from "react";
import {
  useGetArticleCategoriesQuery,
  useDeleteArticleCategoryMutation,
  type ArticleCategoryRecord,
} from "./articleCategory.api";
import { extractApiError } from "../../../lib/apiClient";
import ArticleCategoryModal from "./ArticleCategoryModal";
import ConfirmDialog from "../../../components/common/ConfirmDialog";
import DataTable, { type DataTableColumn } from "../../../components/common/DataTable";
import Pagination from "../../../components/common/Pagination";
import { SearchFilterBar, SearchInput } from "../../../components/common/SearchFilterBar";

const ACCENT = "#D4300F";
const PAGE_SIZE = 20;

export default function AllArticleCategories() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");

  const {
    data: categoriesData,
    isLoading,
    isFetching,
    error: queryError,
  } = useGetArticleCategoriesQuery({
    page,
    limit: PAGE_SIZE,
    search: search || undefined,
  });

  const categories = categoriesData?.data ?? [];
  const pagination = categoriesData?.pagination;
  const loading = isLoading || isFetching;
  const error = queryError ? (queryError as { message?: string }).message ?? "Something went wrong." : "";

  // Modal state — null category = "Add" mode, a record = "Edit" mode.
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<ArticleCategoryRecord | null>(null);

  const openAddModal = () => {
    setEditingCategory(null);
    setModalOpen(true);
  };

  const openEditModal = (category: ArticleCategoryRecord) => {
    setEditingCategory(category);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setEditingCategory(null);
  };

  const [deleteArticleCategory] = useDeleteArticleCategoryMutation();

  const [deletingId, setDeletingId] = useState<number | null>(null);
  // Row pending delete confirmation — set on "Delete" click, cleared on
  // cancel/confirm. Drives the shared ConfirmDialog popup (which itself
  // makes the admin wait a few seconds before the Confirm button
  // enables — no accidental deletes).
  const [pendingDelete, setPendingDelete] = useState<ArticleCategoryRecord | null>(null);
  // Backend blocks this delete with a friendly message when articles
  // are still filed under the category (see articleCategory.service.ts's
  // deleteArticleCategory) — this surfaces that message right here.
  const [actionError, setActionError] = useState("");

  const handleConfirmDelete = async () => {
    if (!pendingDelete) return;
    setActionError("");
    setDeletingId(pendingDelete.id);
    try {
      await deleteArticleCategory(pendingDelete.id).unwrap();
      setPendingDelete(null);
    } catch (err) {
      setActionError(extractApiError(err));
    } finally {
      setDeletingId(null);
    }
  };

  const columns: DataTableColumn<ArticleCategoryRecord>[] = [
    {
      header: "Name",
      render: (c) => (
        <>
          <p className="font-semibold text-[#1c1a17]">{c.name}</p>
          <p className="text-[#a39e96]">{c.slug}</p>
        </>
      ),
    },
    {
      header: "Articles",
      render: (c) => <span className="text-[#7a7670]">{c.articleCount}</span>,
    },
    {
      header: "Status",
      render: (c) => (
        <span
          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
            c.isActive ? "bg-green-50 text-green-600" : "bg-[#f7f5f1] text-[#a39e96]"
          }`}
        >
          {c.isActive ? "Active" : "Inactive"}
        </span>
      ),
    },
    {
      header: "",
      align: "right",
      render: (c) => (
        <div className="flex items-center justify-end gap-1.5">
          <button
            onClick={() => openEditModal(c)}
            className="cursor-pointer text-[10px] font-bold px-2.5 py-1 rounded-lg border border-[#e8e4dc] text-[#4a4640] hover:bg-[#f7f5f1] transition-colors"
          >
            Edit
          </button>
          <button
            onClick={() => setPendingDelete(c)}
            className="cursor-pointer text-[10px] font-bold px-2.5 py-1 rounded-lg border border-red-100 text-red-500 hover:bg-red-50 transition-colors"
          >
            Delete
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-[18px] font-black text-[#1c1a17]">Article Categories</h1>
          <p className="text-[12px] text-[#a39e96] mt-0.5">
            Manage categories used to organize articles. Slug is auto-generated from the name if left blank.
          </p>
        </div>
        <button
          type="button"
          onClick={openAddModal}
          className="cursor-pointer text-[12px] font-bold text-white px-4 py-2.5 rounded-xl transition-opacity hover:opacity-90"
          style={{ background: ACCENT }}
        >
          + Add category
        </button>
      </div>

      {actionError && (
        <div className="flex items-center gap-2 bg-red-50 border border-red-100 rounded-lg px-3.5 py-2.5">
          <p className="text-red-500 text-xs font-medium">{actionError}</p>
        </div>
      )}

      <SearchFilterBar
        right={
          pagination && (
            <p className="text-[11px] text-[#a39e96] whitespace-nowrap">
              {pagination.total} categor{pagination.total === 1 ? "y" : "ies"} total
            </p>
          )
        }
      >
        <SearchInput
          value={search}
          onChange={(v) => {
            setSearch(v);
            setPage(1);
          }}
          placeholder="Search by name or slug..."
        />
      </SearchFilterBar>

      <div className="bg-white border border-[#e8e4dc] rounded-xl overflow-hidden">
        <DataTable
          columns={columns}
          rows={categories}
          rowKey={(c) => c.id}
          loading={loading}
          error={error}
          loadingMessage="Loading article categories..."
          emptyMessage="No article categories found."
        />
        <Pagination pagination={pagination ?? null} onPageChange={setPage} variant="simple" />
      </div>

      {modalOpen && (
        <ArticleCategoryModal
          key={editingCategory ? `edit-${editingCategory.id}` : "add"}
          open={modalOpen}
          onClose={closeModal}
          category={editingCategory}
        />
      )}

      <ConfirmDialog
        open={!!pendingDelete}
        title="Delete category?"
        itemName={pendingDelete?.name}
        message={
          pendingDelete && pendingDelete.articleCount > 0
            ? `${pendingDelete.articleCount} article(s) are linked to this category — deletion will be blocked until they're reassigned.`
            : undefined
        }
        loading={deletingId === pendingDelete?.id}
        onCancel={() => setPendingDelete(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}